import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { HttpClient, HttpErrorResponse, HttpParams} from  '@angular/common/http';
import { UserService } from '../services/user.service';
import { Observable } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-user-wall',
  templateUrl: './user-wall.component.html',
  styleUrls: ['./user-wall.component.css']
})
export class UserWallComponent implements OnInit {
  user:User
  errorMessage:string
  constructor(private http:HttpClient,private userServices:UserService,private route:ActivatedRoute,private router:Router) { }

  ngOnInit() {
          const emailId = this.route.snapshot.paramMap.get("emailId")
          this.userServices.getUser(emailId).subscribe(
            user=>{
              this.user=user
            },
            errorMessage=>{
              this.errorMessage=errorMessage
            }
          )
  }
}