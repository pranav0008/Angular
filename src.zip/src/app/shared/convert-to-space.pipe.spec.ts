import { ConvertToSpacePipe } from './convert-to-space.pipe';
import { Pipe } from '@angular/core';
@Pipe({
  name:'convertToSpace'
})
describe('ConvertToSpacePipe', () => {
  it('create an instance', () => {
    const pipe = new ConvertToSpacePipe();
    expect(pipe).toBeTruthy();
  });
});
