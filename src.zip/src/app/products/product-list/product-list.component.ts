import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProductService } from 'src/app/services/product.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent  implements OnInit{
    constructor(private productService:ProductService) {
        this._listFilter=""
       }
      
      productListTitle:string='Product List';
      error:string
      _listFilter:string=''
      productsList:Product[];
      products: Product[]; 
      product:Product;
      productId:number;
  get listFilter():string{
      return this._listFilter;
  }
  set listFilter(value:string){
      this._listFilter=value;
      this.productsList=this._listFilter ?
       this.doProductFiltering(this._listFilter): this.products
  }
 
ngOnInit(){
    this.productService.getAllProductsDetails().subscribe(
        tempProducts=>{
            this.products=tempProducts;
            this.productsList=this.products;
        }
        ,
        error=>{
            this.error=error;    
        }
    );
    this.productService.getproductDetails(this.productId).subscribe(
tempProduct=>{
    this.product=tempProduct;
},
    error=>{
        this.error=error;
    }
    )
}

doProductFiltering(filterBy:string):Product[]{
    filterBy = filterBy.toLowerCase();
    return this.products.filter(product =>
     product.productName.toLowerCase().indexOf(filterBy)!==-1);
    }
onRatingClicked(message:string):void{
    this.productListTitle = `Products List!!!` + message;
}
}