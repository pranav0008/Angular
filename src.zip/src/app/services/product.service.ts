import { Injectable } from '@angular/core';
import { Product } from '../products/product';
import { Observable, throwError } from 'rxjs'
import { HttpClient,HttpErrorResponse } from '@angular/common/http';
import {map, catchError} from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class ProductService {
  
constructor(private httpClient:HttpClient) { }

public getAllProductsDetails():Observable<Product[]>{
return this.httpClient.get<Product[]>("http://localhost:1234/onlineshopping/allProductDetails").pipe(catchError(this.handleError));
}
public getproductDetails(productId:number):Observable<Product>{
  return this.httpClient.get<Product>("http://localhost:1234/onlineshopping/productDetails?productId=500").pipe(catchError(this.handleError));
}
private handleError(error:any){
  if(error instanceof ErrorEvent){
    console.error(`1 An ErrorEvent occured:`,error.error.message);
    return throwError(error.error.message);
  }else if(error instanceof HttpErrorResponse){
    console.error(`2 Backend returned code ${error.status}, body was: ${error.message}`);
    return throwError(`Backend returned Code ${error.status}, body was: ${error.message}`);
  }
  else if (error instanceof TypeError){
    console.error(`3 TypeError has occured ${error.message}, body was ${error.stack}`);
    return throwError(`TypeError has occured ${error.message}, body was ${error.stack}`);
  }
}
}