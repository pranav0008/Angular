package com.cg.capbook.daoservices;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.capbook.beans.User;

public interface UserDAO extends JpaRepository<User, Integer>{
	
	@Query("select a from User a where a.emailId=:emailId")
	User findByEmail(@Param("emailId") String emailId);
	
	@Query("SELECT a.firstName,a.lastName,a.address.city FROM User a WHERE a.firstName=:firstName")	
	List<User>	getAllUsersByNames(@Param("firstName")String firstName);
		
	@Query("SELECT a FROM User a WHERE a.userId IN "
			+ "(SELECT b.user.userId FROM FriendList b WHERE "
			+ "b.user.userId=:userId and b.friendId=:friendId)")
	List<User> getfriendsDetails(@Param("userId")int userId,@Param("friendId") int friendId);


	@Query("SELECT a.firstName,a.lastName,a.gender,a.emailId,a.dob from User a "
			+ "WHERE a.userId IN (SELECT b.requestId FROM FriendRequest b WHERE "
			+ "b.user.userId=:userIdreceiver and b.requestId=:userIdSender )")
	List<User> getfriendRequests(@Param("userIdreceiver") int userIdreceiver ,@Param("userIdSender") int userIdSender);
}