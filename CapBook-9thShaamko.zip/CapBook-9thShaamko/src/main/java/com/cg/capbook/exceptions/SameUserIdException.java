package com.cg.capbook.exceptions;

public class SameUserIdException extends Exception {

}
