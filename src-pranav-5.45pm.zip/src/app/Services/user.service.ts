import { Injectable } from '@angular/core';
import { User } from '../user';
import { HttpClient, HttpErrorResponse, HttpParams} from  '@angular/common/http';
import { Observer, observable, throwError } from 'rxjs';
import {Observable} from 'rxjs';
import { map, catchError } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class UserService {
  constructor(private httpClient:HttpClient) { }

  private registerUserUrl:string = 'http://localhost:4444/register';

  private userWallUrl:string ='';

  private displayFewUserURL
  public registerUser(user:User):Observable<string>{
    let body = JSON.parse(JSON.stringify(user))
    return this.httpClient.post<string>(this.registerUserUrl, body).pipe(catchError(this.handleError));
  }

  public displayFewUsers(firstName:string):Observable<User[]>{
    return this.httpClient.get<User[]>("").pipe(catchError(this.handleError))

  }  
  private handleError(error:any){
    if(error instanceof ErrorEvent){
      console.error('1 An ErrorEvent occured :',error.error.message);
      return throwError(error.error.message);
    }else if(error instanceof HttpErrorResponse){
      console.error(`2 Backend returned code ${error.status}, body was : ${error.message}`);
      return throwError(`Backend returned code ${error.status}, body was : ${error.message}`);
    }
    else if(error instanceof TypeError){
      console.error(`3 Backend returned code ${error.message}, body was : ${error.stack}`);
       return throwError(`Backend returned code ${error.message}, body was : ${error.stack}`);
    }
  }
}