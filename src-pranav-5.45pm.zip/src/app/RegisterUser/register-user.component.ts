import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { Router } from '@angular/router';
import { UserService } from '../Services/user.service';

@Component({
  selector: 'app-register-user',
  templateUrl: './register-user.component.html',
  styleUrls: ['./register-user.component.css']
})
export class RegisterUserComponent implements OnInit {
  pageTitle: string = "Create a new account today"
  pageDescription: string ="It's free and always will be!"
  errorMessage:string
  constructor(private router:Router,private userService : UserService) { }

  ngOnInit() {
  }
  onSubmit(user:User){
    this.userService.registerUser(user).subscribe(
      errorMessage=>{
        this.errorMessage=errorMessage
      }
    )
    this.router.navigate(['/'])
  }
}
