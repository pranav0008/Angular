import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-user',
  templateUrl: './login-user.component.html',
  styleUrls: ['./login-user.component.css']
})
export class LoginUserComponent implements OnInit {

  pageTitle1:string="Already a user?"
  pageTitle2:string="Sign in here";

  constructor() { }

  ngOnInit() {
  }

}
