import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { UserService } from '../Services/user.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-display-users',
  templateUrl: './display-users.component.html',
  styleUrls: ['./display-users.component.css']
})
export class DisplayUsersComponent implements OnInit {

  constructor(private route:ActivatedRoute,private router:Router,private userService:UserService) { }

  user:User;
  error:string;
  Users:User[];
  firstName:string;
  ngOnInit() {
    const firstName= this.route.snapshot.paramMap.get('firstName');
    this.userService.displayFewUsers(firstName).subscribe(
      tempUser=>{
        this.Users=tempUser;
      },
      error=>{
        this.error=error;
      }
    )
  }
  public navigateBack(): void{
    this.router.navigate(['/userWall']);
  }
}
