import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserWallComponent } from './userWall/user-wall.component';
import { LoginUserComponent } from './LoginUser/login-user.component';
import { RegisterUserComponent } from './RegisterUser/register-user.component';
import { RouterModule } from '@angular/router';
import { DisplayUsersComponent } from './DisplayUsers/display-users.component';
import {FormsModule} from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    UserWallComponent,
    LoginUserComponent,
    RegisterUserComponent,
    DisplayUsersComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      {path:'register', component:RegisterUserComponent},
      {path:'userWall',component:UserWallComponent},
      {path:'fewUsers',component:DisplayUsersComponent}
  ]),
],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
