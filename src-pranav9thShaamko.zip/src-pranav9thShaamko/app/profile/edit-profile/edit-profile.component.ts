import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/user';
import { EditUser } from 'src/app/edit-user';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent implements OnInit {

  user:User
  editUser: EditUser
  errorMessage:string
  successMessage:string
  constructor(private router:Router,private userServices : UserService,private route:ActivatedRoute) { }

  ngOnInit() {
    const emailId = this.route.snapshot.paramMap.get("emailId")
    this.userServices.getUser(emailId).subscribe(
      user=>{
        this.user=user
      },
      errorMessage=>{
        this.errorMessage=errorMessage
      }
    )
  }

  onSubmit(editUser:EditUser){
    this.editUser=editUser
    this.userServices.editUser(editUser).subscribe(
      message=>{
        this.successMessage=message
      },
      message=>{
        this.errorMessage=message
      }
    )
    this.router.navigate(['/wall',this.user.emailId])
  }
}
