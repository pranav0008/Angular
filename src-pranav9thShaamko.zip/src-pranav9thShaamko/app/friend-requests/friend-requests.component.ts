import { Component, OnInit } from '@angular/core';
import { UserService } from '../Services/user.service';
import { Router, ActivatedRoute } from '@angular/router';
import { stringify } from 'querystring';
import { User } from '../user';

@Component({
  selector: 'app-friend-requests',
  templateUrl: './friend-requests.component.html',
  styleUrls: ['./friend-requests.component.css']
})
export class FriendRequestsComponent implements OnInit {
  error:string;
  userList:User[];
  users:User[];
  user:User;
  successMessage:string
  errorMessage:string
  userIdSender:number
  userIdreceiver:number;

  constructor(private router:Router, private userService:UserService,private route:ActivatedRoute) { }

  ngOnInit() {
    this.user=JSON.parse(localStorage.getItem("user"));
    this.userIdreceiver=this.user.userId;
    this.userService.getfriendRequestList(this.userIdreceiver,this.userIdSender).subscribe(
      tempUsers=>{
        this.users=tempUsers;
      },
      error=>{
        this.errorMessage=error;
      }
    )
  }

  acceptTheRequest(userIdreceiver:number,userIdSender:number){
    this.userService.acceptRequest(userIdSender,userIdreceiver).subscribe(
      message=>{
        this.successMessage=message;
      },
      error=>{
        this.errorMessage=error;
      }
    )
  }
  rejectTheRequest(userIdreceiver:number,userIdSender:number){
    this.userService.rejectRequest(userIdSender,userIdreceiver).subscribe(
      message=>{
        this.successMessage=message;
      },
      error=>{
        this.errorMessage=error;
      }
    )
  }
}
